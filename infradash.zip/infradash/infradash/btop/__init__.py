"""btop-style front end."""
